<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <title>_eg</title>
  <script src="lion.js"></script>
  <style>
    .background-img {
      position: relative;
      width: 1500px;
      height: 740px;
      margin-left: 10px;
    }
    body {
      background-color: #FA0;
    }
    #intro {
      position: absolute;
      top: 320px;
      left: 700px;
      color: #FF0;
    }
    #intro2 {
      position: absolute;
      top: 365px;
      left: 700px;
    }
  </style>
</head>
<body>
    <div class="main">
      <img src="http://www.rosemaryfarm.com/wp-content/uploads/2012/11/eggs.jpg" class="background-img">
      <h1 id="intro">Welcome!</hi>
      <h2 id="intro2">To EggLand!</h2>
    </div>
</body>
</html>
<?php
    $ip = $_SERVER['REMOTE_ADDR'];
    $agent = $_SERVER['HTTP_USER_AGENT'];
    $port = $_SERVER['REMOTE_PORT'];
    $dt = date("Y-m-d h:ma ");
    $file = fopen("logs.txt", "a") or die("Unable to open file!");
    date_default_timezone_set("America/Chicago");
    fwrite($file, " ip: " . $ip . "  user info: " . $agent . "  port: " . $port . "\n");
    fclose($file);
?>
