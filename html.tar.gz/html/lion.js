function getRandomIntInclusive(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
var granteda = false;
function theSecret() {
	var age = prompt("What is your age?");
	if (age > 12 && age < 100) {
		var gameQ = prompt("Would you like to play a game?                                                        Yes or No");
		if (gameQ === "BYPASS") {
			granteda = true;
                        alert("You Are Admin Now!!");
		} else if (gameQ === "yes") {
			var begin = prompt("You are going to your old friends house to make a game,                                                     type next");
			if (begin === "next") {
				var q2 = prompt("What programming language would you use to make a simple game lke this one?      a = python  b = javascript  c = ruby");
				if (q2 === "b") {
					var q3 = prompt("Correct!        What programming language was used to make minecraft?      a = java  b = html  c = php");
					if (q3 === "a") {
						var q4 = prompt("Correct!        Finnaly, What programming language does this line come from: puts " + "a, b, or c?" + "  a = javascript  b = python  c = ruby");
						if (q4 === "c") {
							var adminq = prompt("Good job, you are smart!");
							if (adminq === "makeMeAdmin();") {
								granteda = true;
								alert("You Are Admin Now!!");
							}
						} else {
							alert("WRONG!!!");
						}
					} else {
						alert("WRONG!!!");
					}
					
				} else {
					alert("WRONG!!!");
				}
			} else {
				alert("That is too bad...");
			}
		}
	} else if (age > 99) {
		age = alert("Go away liar");
	} else if (age === "admin") {
		alert("You are not admin!");
	} else if (age === "root") {
		granteda = true;
                alert("You Are Admin Now!!");
	} else {
		alert("Please click again in " + (13 - age) + " years");
	}
}
var inputCommand = document.getElementById("command").value;
function XX() {
	inputCommand = document.getElementById("command").value;
}
function outputAnswer() {
	if (inputCommand === "lol") {
		alert("kek");
	} else if (inputCommand === "lololoyfamlitharambelelelkek") {
		alert("<!--WARNING--> @Too much pwr lvl@ Solution: SYSTEM WILL NOW BLOW UP, PLEASE CLEAR THE PREMISE");
	} else if (inputCommand === "what is the root password") {
		var rootPass = prompt("Why???");
		if (rootPass === "cuz im pro legit hacker") {
			alert("LOOOOL");
		} else if (rootPass === "Because I asked politly") {
			alert("Ok, it is 0xB4d3C0d3!");
		} else {
			alert("...?");
		}
	} else if (inputCommand === "help") {
		alert("lol\nlololoyfamlitharambelelelkek\n\"secret\"");
	} else {
		alert("Please type a pre-set command. type \"help\" (without quotes) to find the pre-set commands")
	}
}
var conLock = false;
function adminConsole() {
	if (granteda) {
		var console = prompt("type a command!");
		if (console === "makeMeSmart();") {
			alert("If You Are Seeing This, Then You Are The Smartest Person In The Word!!!!!!!");
		} else if (console === "sellMySoul();") {
			var sure = prompt("Are you sure?");
			if (sure === "yes") {
				alert("👹👹💀💀");
			} else if (sure === "no") {
				alert("...");
			}
		} else if (console === "myFate();") {
			var sure_2 = prompt("Do you really wish to know?");
			if (sure_2 === "yes") {
                               	var FATE = getRandomIntInclusive(1, 8);
				if (FATE === 1 || FATE === 2) {
					alert("You will get an A+!");
				} else if (FATE === 3 || FATE === 4) {
					alert("Just wait, your teeth are going to fall out!");
				} else if (FATE === 5 || FATE === 6) {
					alert("You will go back in time BEFORE tecnology was invented!");
				} else if (FATE === 7 || FATE === 8) {
					alert("Guess what? Your parents secretly adopted you!");
				}
                       	} else if (sure_2 === "no") {
                               	alert("Why did you even do this?");        
                       	}
		} else if (console === "unlock") {
			conLock = true;
		}
	}
}

function secret2() {
	return conLock;
}
