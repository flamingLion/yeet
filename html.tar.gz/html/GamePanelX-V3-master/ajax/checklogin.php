<?php
// Check logged-in
if(!isset($_SESSION['gpx_userid'])) die('You must be logged-in to do that!');
?>