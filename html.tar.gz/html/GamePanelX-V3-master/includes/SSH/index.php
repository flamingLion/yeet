<?php
echo '<html><head></head><body></body></html>';
exit;
?>
