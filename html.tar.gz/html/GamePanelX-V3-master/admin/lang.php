<?php
// Assign the correct language
require('../languages/english.php');
?>
