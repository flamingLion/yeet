<?php
// Main GamePanelX Configuration File
$settings['db_host']      = 'localhost'; // No need to change this
$settings['db_name']      = 'GamePanelX'; // Your database name
$settings['db_username']  = 'root'; // Your database username
$settings['db_password']  = 'root'; // Your database password
$settings['docroot']      = '/var/www/html/GamePanelX-V3-master/'; // Set to the full path to your GamePanelX installation e.g. /home/me/public_html/gpx/
$settings['enc_key']      = 'aCjc4GzTNRyTBH7uCgU9MVOKb835m6BF2igFzNqBETAMFKkUmy8Fc1sBkoofLNW'; // No need to change this
$settings['debug']        = false;

###################################

/* No need to edit these! */
if(!defined('DOCROOT'))
{
    define('DOCROOT', $settings['docroot']);
    define('GPXDEBUG', $settings['debug']);
}

date_default_timezone_set('US/Central');

if($settings['debug']) error_reporting(E_ALL);
else error_reporting(E_ERROR);

?>